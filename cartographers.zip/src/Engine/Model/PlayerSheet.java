package Engine.Model;

public class PlayerSheet {
    private String name;
    private Board board;
    private int accumulatedGold;
    private int score;

    public PlayerSheet(String name, Board board) {
        this.name = name;
        this.board = board;
        accumulatedGold =0;
        score = 0;
    }

    public void setScore(int i) {
        score+=i;
    }

    public Board getBoard() {
        return board;
    }

    //do we need this?
    public ValidationResult check(PlayerTilesSelection playerTilesSelection, DiscoveryCard currentDiscoveryCard) {
        ValidationResult one = currentDiscoveryCard.check(playerTilesSelection);
        boolean yieldsGold=currentDiscoveryCard.yieldsGold(playerTilesSelection);
        ValidationResult two = this.board.check(playerTilesSelection,yieldsGold);
        if (one==ValidationResult.Ok && two==ValidationResult.Ok)
            return ValidationResult.Ok;
        if(one!=ValidationResult.Ok)
            return one;
        return two;
    }

    public ValidationResult execute(PlayerTilesSelection playerTilesSelection, DiscoveryCard currentDiscoveryCard) {
        ValidationResult vr = check(playerTilesSelection, currentDiscoveryCard);
        if(vr!=ValidationResult.Ok)
            return vr;
        ExecutionResult er = this.board.execute(playerTilesSelection, false);
        if(er.getResult()!=ValidationResult.Ok)
            return er.getResult();
        this.accumulatedGold+=er.getGoldYield();
        if(currentDiscoveryCard.yieldsGold(playerTilesSelection))
            this.accumulatedGold++;
        return ValidationResult.Ok;
    }

    public int getAccumulatedGold() {
        return accumulatedGold;
    }
}
