package Engine.Model;

public enum DiscoveryCardType {
    Normal,
    Ruin,
    Ambush
}
