package Engine.Model;

public enum Seasons {
    spring,
    summer,
    autumn,
    winter
}
