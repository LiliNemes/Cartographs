package Engine.Model;

import java.util.ArrayList;
import java.util.List;

public class Board {

    private TerrainType[][] tiles;
    private List<Coordinate> ruins;
    int boardSize;

    public int getBoardSize() {
        return boardSize;
    }

    public Board(int size, List<Coordinate> mountains, List<Coordinate> rifts) {
        boardSize=size;
        tiles = new TerrainType[boardSize][boardSize];

        // reset everything to empty
        for (int i=0; i<boardSize; i++) {
            for (int j=0; j<boardSize; j++) {
                tiles[i][j] = TerrainType.Empty;
            }
        }
        //hegy nem lehet a térkép szélén
        fillCoordinates(mountains, TerrainType.Mountain);
        fillCoordinates(rifts, TerrainType.Rift);
    }

    private void fillCoordinates(List<Coordinate> coordinates, TerrainType terrainType) {
        if (coordinates == null) return;
        for (int idx=0; idx<coordinates.size(); idx++) {
            int x = coordinates.get(idx).getX();
            int y = coordinates.get(idx).getY();
            tiles[x][y] = terrainType;
        }
    }

    public ValidationResult check(PlayerTilesSelection playerTilesSelection, boolean isThereRuin) {
        //TODO check dimensions, empty fields, etc.
        List<SelectedTile> selectedTiles=playerTilesSelection.getSelectedTiles();
        for(int i=0; i<selectedTiles.size(); i++) {
            if(selectedTiles.get(i).getX()<0 || selectedTiles.get(i).getX()>boardSize-1)
                return ValidationResult.NotOnTheMap;
            if(selectedTiles.get(i).getY()<0 || selectedTiles.get(i).getY()>boardSize-1)
                return ValidationResult.NotOnTheMap;
            if(selectedTiles.get(i).getTerrainType()!=TerrainType.Empty)
                return ValidationResult.TileNotEmpty;
        }
        return ValidationResult.Ok;
    }

    public ExecutionResult execute(PlayerTilesSelection playerTilesSelection, boolean isThereRuin) {
        int goldYield=0;
        List<Coordinate> mountains = new ArrayList<>();
        for (int i=0; i<boardSize; i++) {
            for (int j=0; j<boardSize; j++) {
                if(tiles[i][j]==TerrainType.Mountain) {
                    if(tiles[i-1][j]==TerrainType.Empty || tiles[i+1][j]==TerrainType.Empty
                    || tiles[i][j-1]==TerrainType.Empty || tiles[i][j+1]==TerrainType.Empty) {
                        Coordinate e=new Coordinate(i, j);
                        mountains.add(e);
                    }

                }
            }
        }
        var result = check(playerTilesSelection, isThereRuin);
        if (result == ValidationResult.Ok) {
            for (int i = 0; i < playerTilesSelection.getSelectedTiles().size(); i++) {
                int x = playerTilesSelection.getSelectedTiles().get(i).getX();
                int y = playerTilesSelection.getSelectedTiles().get(i).getY();
                TerrainType t = playerTilesSelection.getSelectedTiles().get(i).getTerrainType();
                this.tiles[x][y] = t;
            }

            for (int i = 0; i < mountains.size(); i++) {
                int x = mountains.get(i).getX();
                int y = mountains.get(i).getY();
                if (tiles[x - 1][y] != TerrainType.Empty && tiles[x + 1][y] != TerrainType.Empty &&
                        tiles[x][y - 1] != TerrainType.Empty && tiles[x][y + 1] != TerrainType.Empty) {
                    goldYield++;
                }
            }
            return new ExecutionResult(ValidationResult.Ok, goldYield);
        }
        else {
            return new ExecutionResult(result, 0);
        }
    }

    public TerrainType getTerrainType(Coordinate coordinate) {
        return tiles[coordinate.getX()][coordinate.getY()];
    }

    public List<TerrainType> getNeighboursTerrainType (Coordinate coordinate) {
        List<TerrainType> neighbours=new ArrayList<>();
        if(coordinate.getX()!=0) {
            neighbours.add(tiles[coordinate.getX() - 1][coordinate.getY()]);
        }
        if(coordinate.getX()!=boardSize-1) {
            neighbours.add(tiles[coordinate.getX() + 1][coordinate.getY()]);
        }
        if(coordinate.getY()!=0) {
            neighbours.add(tiles[coordinate.getX()][coordinate.getY() - 1]);
        }
        if(coordinate.getY()!=boardSize-1) {
            neighbours.add(tiles[coordinate.getX()][coordinate.getY() + 1]);
        }
        return neighbours;
    }
    public List<Coordinate> sameTerrainTypeNeighbours (Coordinate coordinate) {
        List<Coordinate> neighbours = new ArrayList<>();
        if(coordinate.getX()!=0) {
            Coordinate c= new Coordinate(coordinate.getX()-1, coordinate.getY());
            if(this.getTerrainType(c)==this.getTerrainType(coordinate))
                neighbours.add(c);
        }
        if(coordinate.getX()!=boardSize-1) {
            Coordinate c= new Coordinate(coordinate.getX()+1, coordinate.getY());
            if(this.getTerrainType(c)==this.getTerrainType(coordinate))
                neighbours.add(c);
        }
        if(coordinate.getY()!=0) {
            Coordinate c= new Coordinate(coordinate.getX(), coordinate.getY()-1);
            if(this.getTerrainType(c)==this.getTerrainType(coordinate))
                neighbours.add(c);
        }
        if(coordinate.getY()!=boardSize-1) {
            Coordinate c= new Coordinate(coordinate.getX(), coordinate.getY()+1);
            if(this.getTerrainType(c)==this.getTerrainType(coordinate))
                neighbours.add(c);
        }
        return neighbours;
    }

    public List<Coordinate> neighbourNotInIt(List<Coordinate> region, Coordinate coordinate) {
        List<Coordinate> ret = new ArrayList<>();
        for(int i=0; i<this.sameTerrainTypeNeighbours(coordinate).size(); i++) {
            boolean notInIt=true;
            for(int j=0; j< region.size(); j++) {
                if(region.get(j)==this.sameTerrainTypeNeighbours(coordinate).get(j))
                    notInIt=false;
            }
            if(notInIt)
                ret.add(this.sameTerrainTypeNeighbours(coordinate).get(i));
        }
        return ret;
    }

    public List<List<Coordinate>> getRegions(TerrainType t) {
        List<List<Coordinate>> allRegions = new ArrayList<>();
        for(int i=0; i<boardSize; i++) {
            for(int j=0; j<boardSize; j++) {
                if(this.tiles[i][j]==t) {
                    Coordinate c = new Coordinate(i, j);
                    boolean notInIt = true;
                    for(int n=0; n<allRegions.size(); n++) {
                        for(int m=0; m<allRegions.get(n).size(); m++) {
                            if(allRegions.get(n).get(m)==c)
                                notInIt=false;
                        }
                    }
                    if(notInIt) {
                        List<Coordinate> oneRegion = new ArrayList<>();
                        oneRegion.add(c);
                        List<Coordinate> okNeighbours= this.neighbourNotInIt(oneRegion, c);
                        int check=okNeighbours.size();
                        for(int p=0; p<okNeighbours.size(); p++) {
                            oneRegion.add(okNeighbours.get(p));
                        }
                        while(check>0) {
                            int param=0;
                            for(int h=0; h<oneRegion.size(); h++) {
                                Coordinate e=oneRegion.get(h);
                                List<Coordinate> okNeighbours2= this.neighbourNotInIt(oneRegion, e);
                                param+= okNeighbours2.size();
                                for(int p=0; p<okNeighbours2.size(); p++) {
                                    oneRegion.add(okNeighbours2.get(p));
                                }
                            }
                            check=param;
                        }
                        allRegions.add(oneRegion);

                    }

                }
            }
        }
        return allRegions;
    }
}
