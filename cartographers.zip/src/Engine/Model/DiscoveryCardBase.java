package Engine.Model;

public class DiscoveryCardBase {
    private DiscoveryCardType cardType;
    private String name;

    public DiscoveryCardBase(DiscoveryCardType cardType, String name) {
        this.cardType = cardType;
        this.name = name;
    }

    public DiscoveryCardType getCardType() {
        return cardType;
    }

    public String getName() {
        return name;
    }
}
