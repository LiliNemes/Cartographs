package Engine.Model;

public enum ValidationResult {
    Ok,
    InvalidArrangement,
    DifferentTerrains,
    InvalidTerrain,
    NotOnTheMap,
    TileNotEmpty

}
