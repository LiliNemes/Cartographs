package Engine.Model;

public class SelectedTile {
    private int x;
    private int y;
    private TerrainType terrainType;

    public SelectedTile(int x, int y, TerrainType terrainType) {
        this.x = x;
        this.y = y;
        this.terrainType = terrainType;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public TerrainType getTerrainType() {
        return terrainType;
    }
}
