package Engine.Model;

import java.util.ArrayList;
import java.util.List;

public class Layout {
    private List<Coordinate> coordinates;

    public static Layout createLayout(String inp) {
        return new Layout(Coordinate.parseList(inp));
    }

    public Layout(List<Coordinate> coordinates) {
        this.coordinates = coordinates;
    }

    public boolean IsMatch(Layout otherLayout) {
        //matches if all coordinates are match, regardless of order

        //size diff means no match
        if (otherLayout.coordinates.size() != coordinates.size()) return false;

        for (int i = 0; i < otherLayout.coordinates.size(); i++) {
            var otherCord = otherLayout.coordinates.get(i);
            if (!this.HasCoordinate(otherCord)) return false;
        }
        return true;
    }

    public Layout turn90degrees(int times) {
        int biggestX=this.coordinates.get(0).getX();
        int biggestY=this.coordinates.get(0).getY();
        for(int i=0; i<this.coordinates.size(); i++) {
            if(this.coordinates.get(i).getX()>biggestX)
                biggestX=this.coordinates.get(i).getX();
            if(this.coordinates.get(i).getY()>biggestY)
                biggestY=this.coordinates.get(i).getY();
        }
        int param;
        if(biggestX>biggestY)
            param=biggestX;
        else {
            param=biggestY;
        }
        List<Coordinate> turnedCoordinates = new ArrayList<>();
        for (int i=0; i<this.coordinates.size(); i++) {
            int x=this.coordinates.get(i).getY();
            int y=(-1 * this.coordinates.get(i).getX()) + param;
            for (int j=0; j<times-1; j++) {
                int p = x;
                x=y;
                y=(p*-1)+param;
            }
            Coordinate turned = new Coordinate(x, y);
            turnedCoordinates.add(turned);
        }
        Layout turned=new Layout(turnedCoordinates);
        turned=turned.project();
        return turned;
    }

    public Layout project() {
        int smallestX=this.coordinates.get(0).getX();
        int smallestY=this.coordinates.get(0).getY();
        for(int i=0; i<this.coordinates.size(); i++) {
            if(this.coordinates.get(i).getX()<smallestX)
                smallestX=this.coordinates.get(i).getX();
            if(this.coordinates.get(i).getY()<smallestY)
                smallestY=this.coordinates.get(i).getY();
        }
        List<Coordinate> projectedCoordinates = new ArrayList<>();
        for(int i=0; i<this.coordinates.size(); i++) {
            int x=this.coordinates.get(i).getX()-smallestX;
            int y=this.coordinates.get(i).getY()-smallestY;
            Coordinate c=new Coordinate(x, y);
            projectedCoordinates.add(c);
        }
        Layout projected= new Layout(projectedCoordinates);
        return projected;
    }

    public Layout mirror() {
        int biggestX=this.coordinates.get(0).getX();
        for(int i=0; i<this.coordinates.size(); i++) {
            if(this.coordinates.get(i).getX()>biggestX)
                biggestX=this.coordinates.get(i).getX();
        }
        List<Coordinate> mirroredCoordinates = new ArrayList<>();
        for(int i=0; i<this.coordinates.size(); i++) {
            int x = biggestX - this.coordinates.get(i).getX();
            Coordinate c = new Coordinate(x, this.coordinates.get(i).getY());
            mirroredCoordinates.add(c);
        }
        Layout mirrored = new Layout(mirroredCoordinates);
        mirrored=mirrored.project();
        return mirrored;
    }

    private boolean HasCoordinate(Coordinate coordinate) {
        for (int i = 0; i < coordinates.size(); i++) {
            if (coordinates.get(i).Equals(coordinate)) return true;
        }
        return false;
    }
}
