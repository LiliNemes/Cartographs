package Engine.Model;

import Engine.Builder.ArrangementRuleFactory;

import java.util.Collections;
import java.util.List;

public class DiscoveryCardDeck {

    private List<DiscoveryCardBase> cards;
    private int time;
    private int current;

    public DiscoveryCardDeck(List<DiscoveryCardBase> cards) {
        this.cards = cards;
        this.time = 0;
        this.current = -1;
    }

    public static DiscoveryCardDeck createDeck(boolean useAmbushCards) {
        var deck = new DiscoveryCardDeck(
                List.of(Marshlands, Hamlet, Orchard, FishingVillage, GreatRiver, Farmland, ForgottenForest,
                        HinterlandStream, Homestead, TreetopVillage, RiftLands,  RuinsCard.OutpostRuins,
                        RuinsCard.TempleRuins));
        deck.shuffle();
        return deck;
    }

    public void shuffle() {
        Collections.shuffle(this.cards);
    }

    public DiscoveryCardBase draw() {
        var newCard = cards.get(++current);
        if (newCard.getCardType() == DiscoveryCardType.Normal)
        {
            var discoveryCard = (DiscoveryCard)newCard;
            time += discoveryCard.getTimeCost();
        }
        return newCard;
    }

    public DiscoveryCardBase getCurrent() {
        if (current < 0 || current >= cards.size())
            return null;
        return cards.get(current);
    }

    public int getTime() {
        return time;
    }

    public static DiscoveryCard Marshlands = new DiscoveryCard("Marshlands", 2,
            List.of(
                    ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0;0,1;0,2;1,1;2,1"), false)
            ),
            List.of(TerrainType.Forest, TerrainType.Water));

    public static DiscoveryCard Hamlet = new DiscoveryCard("Hamlet", 1,
            List.of(
                    ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0;0,1;1,1"), true),
                    ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0;1,0;2,0;0,1;1,1"), false)
            ),
            List.of(TerrainType.Village));

    public static DiscoveryCard Orchard = new DiscoveryCard("Orchard", 2,
            List.of(
                    ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0;1,0;2,0;2,1"), false)
            ),
            List.of(TerrainType.Farm, TerrainType.Forest));

    public static DiscoveryCard FishingVillage = new DiscoveryCard("Fishing Village", 2,
            List.of(
                    ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0;1,0;2,0;3,0"), false)
            ),
            List.of(TerrainType.Village, TerrainType.Water));

    public static DiscoveryCard GreatRiver = new DiscoveryCard("Great River", 1,
            List.of(
                    ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0;0,1;0,2"), true),
                    ArrangementRuleFactory.buildBasedOn(Layout.createLayout("2,0;1,1;2,1;0,2;1,2"), false)
            ),
            List.of(TerrainType.Water));

    public static DiscoveryCard Farmland = new DiscoveryCard("Farmland", 1,
            List.of(
                    ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0;0,1"), true),
                    ArrangementRuleFactory.buildBasedOn(Layout.createLayout("1,0;0,1;1,1;1,2;2,1"), false)
            ),
            List.of(TerrainType.Farm));

    public static DiscoveryCard ForgottenForest = new DiscoveryCard("Forgotten Forest", 1,
            List.of(
                    ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0;1,1"), true),
                    ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0;0,1;1,1;1,2"), false)
            ),
            List.of(TerrainType.Forest));

    public static DiscoveryCard HinterlandStream = new DiscoveryCard("Hinterland Stream", 2,
            List.of(
                    ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0;0,1;0,2;1,0;2,0"), false)
            ),
            List.of(TerrainType.Farm, TerrainType.Water));

    public static DiscoveryCard Homestead = new DiscoveryCard("Homestead", 2,
            List.of(
                    ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0;0,1;0,2;1,1"), false)
            ),
            List.of(TerrainType.Village, TerrainType.Farm));

    public static DiscoveryCard TreetopVillage = new DiscoveryCard("Treetop Village", 2,
            List.of(
                    ArrangementRuleFactory.buildBasedOn(Layout.createLayout("2,0;3,0;0,1;1,1;2,1"), false)
            ),
            List.of(TerrainType.Village, TerrainType.Forest));

    public static DiscoveryCard RiftLands = new DiscoveryCard("Rift Lands", 0,
            List.of(
                    ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0"), false)
            ),
            List.of(TerrainType.Village, TerrainType.Water, TerrainType.Forest, TerrainType.Farm, TerrainType.Monster));
}
