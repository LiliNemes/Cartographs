package Engine.Model;

import java.util.List;

public class DiscoveryCard extends DiscoveryCardBase {
    private int timeCost;
    private List<ArrangementRule> possibleArrangementRules;
    private List<TerrainType> possibleTerrainTypes;

    public DiscoveryCard(String name, int timeCost, List<ArrangementRule> possibleArrangementRules, List<TerrainType> possibleTerrainTypes) {
        super(DiscoveryCardType.Normal, name);
        this.timeCost = timeCost;
        this.possibleArrangementRules = possibleArrangementRules;
        this.possibleTerrainTypes = possibleTerrainTypes;
    }

    public ValidationResult check(PlayerTilesSelection playerTilesSelection) {

        boolean firstCheck = playerTilesSelection.areAllTerrainsSame();
        if(!firstCheck)
            return ValidationResult.DifferentTerrains;
        TerrainType type=playerTilesSelection.getTerrain();
        boolean okTerrain=false;
        for(int i=0; i<possibleTerrainTypes.size(); i++) {
            if(type==possibleTerrainTypes.get(i))
                okTerrain=true;
        }
        if(!okTerrain)
            return ValidationResult.InvalidTerrain;
        Layout a=playerTilesSelection.GetLayout();
        boolean okLayout=false;
        for(int i=0; i<possibleArrangementRules.size(); i++) {
            ValidationResult vr = possibleArrangementRules.get(i).Check(playerTilesSelection);
            if(vr==ValidationResult.Ok)
                okLayout=true;
        }
        if(!okLayout)
            return ValidationResult.InvalidArrangement;
        return ValidationResult.Ok;
    }

    public boolean yieldsGold(PlayerTilesSelection playerTilesSelection) {
        for(int i=0; i<possibleArrangementRules.size(); i++) {
            if(possibleArrangementRules.get(i).isYieldsGold()) {
                ValidationResult vr = possibleArrangementRules.get(i).Check(playerTilesSelection);
                if(vr==ValidationResult.Ok)
                    return true;
            }
        }
        return false;
    }

    public int getTimeCost() {
        return timeCost;
    }
}
