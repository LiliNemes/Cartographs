package Engine.Model;

public class AmbushCard extends DiscoveryCardBase {
    public AmbushCard(String name) {
        super(DiscoveryCardType.Ambush, name);
    }
}
