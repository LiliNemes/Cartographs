package Engine.Model;

public enum TerrainType {
    Forest,
    Village,
    Farm,
    Water,
    Mountain,
    Monster,
    Empty, //not filled yet
    Rift  //cannot place a thing here
}
