package Engine.Model;

import java.util.ArrayList;
import java.util.List;

public class PlayerTilesSelection {
    private ArrayList<SelectedTile> selectedTiles;

    private static final List<TerrainType> VALID_TERRAIN_TYPES = List.of(TerrainType.Farm,
                                                                       TerrainType.Forest,
                                                                       TerrainType.Village,
                                                                       TerrainType.Water);

    public PlayerTilesSelection() {
        selectedTiles = new ArrayList<SelectedTile>();
    }

    public ArrayList<SelectedTile> getSelectedTiles() {return selectedTiles;}

    public void AddTile(int x, int y, TerrainType terrainType) throws Exception {
        if (!VALID_TERRAIN_TYPES.contains(terrainType)) {
            throw new Exception("Selected terrain type is not valid.");
        }

        //remove if we already have something at these coordinates
        var tile = GetTileByCoordinates(x, y);
        if (tile != null) {
            selectedTiles.remove(tile);
        }

        selectedTiles.add(new SelectedTile(x, y, terrainType));
    }

    //WHAT?
    public TerrainType GetTerrainType(int x, int y) throws Exception {
        var tile = GetTileByCoordinates(x, y);
        if (tile == null) {
            throw new Exception(String.format("Tile not found at coordinates %s, %s.",x, y));
        }
        return tile.getTerrainType();
    }

    // Returns the layout of the selection using the smallest bounding box
    public Layout GetLayout() {
        if (selectedTiles.size() == 0) {
            return null;
        }

        /*int smallestX = selectedTiles.get(0).getX();
        int smallestY = selectedTiles.get(0).getY();

        for (int i = 1; i < selectedTiles.size(); i++) {
            SelectedTile tile = selectedTiles.get(i);
            if (tile.getX() < smallestX) smallestX = tile.getX();
            if (tile.getY() < smallestY) smallestY = tile.getY();
        }

        List<Coordinate> coordinates = new ArrayList<Coordinate>();
        for (int i = 0; i < selectedTiles.size(); i++) {
            SelectedTile tile = selectedTiles.get(i);
            coordinates.add(new Coordinate(tile.getX()-smallestX, tile.getY()-smallestY));
        }*/
        List<Coordinate> coordinates = new ArrayList<>();
        for(int i=0; i< selectedTiles.size(); i++) {
            SelectedTile tile = selectedTiles.get(i);
            coordinates.add(new Coordinate(tile.getX(), tile.getY()));
        }
        Layout ret = new Layout(coordinates);
        ret=ret.project();
        return ret;
    }

    public TerrainType getTerrain() {
        return this.selectedTiles.get(0).getTerrainType();
    }
    public boolean areAllTerrainsSame() {
        TerrainType terrain = this.selectedTiles.get(0).getTerrainType();
        for(int i=0; i<this.selectedTiles.size(); i++) {
            if(this.selectedTiles.get(i).getTerrainType()!= terrain)
                return false;
        }
        return true;
    }

    private SelectedTile GetTileByCoordinates(int x, int y) {
        for (int i = 0; i < selectedTiles.size(); i++) {
            SelectedTile tile = selectedTiles.get(i);
            if (tile.getX() == x && tile.getY() == y) {
                return tile;
            }
        }
        return null;
    }

    public void ClearAll() {
        selectedTiles.clear();
    }
}
