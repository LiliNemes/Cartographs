package Engine.Model;

import java.util.ArrayList;
import java.util.List;

public class Coordinate {
    private int x;
    private int y;

    public Coordinate(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public boolean Equals(Coordinate coordinate) {
        return coordinate.getX() == x && coordinate.getY() == y;
    }

    public static Coordinate parse(String inp) {
        String[] pair = inp.split(",");
        Coordinate coordinate = new Coordinate(Integer.parseInt(pair[0]), Integer.parseInt(pair[1]));
        return coordinate;
    }

    public static List<Coordinate> parseList(String inp) {
        List<Coordinate> result = new ArrayList<>();
        String[] split = inp.split(";");
        for(int i=0; i< split.length; i++) {
            result.add(Coordinate.parse(split[i]));
        }
        return result;
    }
}
