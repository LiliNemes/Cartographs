package Engine.Model;

public class ExecutionResult {
    private ValidationResult result;
    private int goldYield;

    public ExecutionResult(ValidationResult vr, int g) {
        result=vr;
        goldYield=g;
    }

    public ValidationResult getResult() {
        return result;
    }

    public int getGoldYield() {
        return goldYield;
    }
}
