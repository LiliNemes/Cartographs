package Engine.Builder;

import Engine.Model.ArrangementRule;
import Engine.Model.Layout;

import java.util.*;

public class ArrangementRuleFactory {

    public static ArrangementRule buildBasedOn(Layout layout, boolean yieldsGold) {

        ArrayList<Layout> allLayouts = new ArrayList<>();
        allLayouts.add(layout);

        //add all rotates + mirror with rotates
        for(int i=1; i<3; i++) {
            Layout turned=layout.turn90degrees(i);
            allLayouts.add(turned);
        }
        Layout mirrored = layout.mirror();
        allLayouts.add(mirrored);
        for(int i=1; i<3; i++) {
            Layout turned=mirrored.turn90degrees(i);
            allLayouts.add(turned);
        }
        //maybe clean up duplicates ?

        return new ArrangementRule(allLayouts, yieldsGold);
    }

}
