package Engine;

import Engine.Model.Board;
import Engine.Model.Coordinate;
import Engine.Model.TerrainType;
import org.junit.Test;
import static org.junit.Assert.*;

public class BoardTest {

    @Test
    public void initWorks() {
        var board = new Board(5, Coordinate.parseList("1,1"), Coordinate.parseList("2,2"));
        assertEquals(TerrainType.Empty, board.getTerrainType(new Coordinate(0,0)));
        assertEquals(TerrainType.Mountain, board.getTerrainType(new Coordinate(1,1)));
        assertEquals(TerrainType.Rift, board.getTerrainType(new Coordinate(2,2)));
    }
}
