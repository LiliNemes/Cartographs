package Engine;

import Engine.Model.Layout;
import org.junit.Test;
import static org.junit.Assert.*;

public class LayoutTest {

    @Test
    public void matchesDespiteOfOrder() {
        Layout layout1 = Layout.createLayout("0,0;1,0;2,0");
        Layout layout2 = Layout.createLayout("1,0;0,0;2,0");

        assertTrue(layout1.IsMatch(layout2));
    }

    @Test
    public void turn90degreeSingleLine() {
        Layout input = Layout.createLayout("0,0;1,0;2,0");
        Layout expected = Layout.createLayout("0,0;0,1;0,2");
        Layout result = input.turn90degrees(1);
        assertTrue(result.IsMatch(expected));
    }

    @Test
    public void turn180degreeSingleLine() {
        Layout input = Layout.createLayout("0,0;1,0;2,0");
        Layout result = input.turn90degrees(2);
        assertTrue(result.IsMatch(input));
    }

    @Test
    public void turn450degreeSingleLine() {
        Layout input = Layout.createLayout("0,0;1,0;2,0");
        Layout expected = Layout.createLayout("0,0;0,1;0,2");
        Layout result = input.turn90degrees(5);
        assertTrue(result.IsMatch(expected));
    }

    @Test
    public void turn270degreeStairs() {
        Layout input = Layout.createLayout("2,0;2,1;1,2;1,1;0,2");
        Layout expected = Layout.createLayout("0,0;0,1;1,1;1,2;2,2");
        Layout result= input.turn90degrees(3);
        assertTrue(result.IsMatch(expected));
    }

    @Test
    public void turn90degreeCross() {
        Layout input = Layout.createLayout("1,0;0,1;1,1;2,1;1,2");
        Layout result = input.turn90degrees(1);
        assertTrue(result.IsMatch(input));
    }

    @Test
    public void turn180degreesLShape() {
        Layout input = Layout.createLayout("0,0;1,0;2,0;2,1");
        Layout result = input.turn90degrees(2);
        Layout expected = Layout.createLayout("0,0;0,1;1,1;2,1");
        assertTrue(result.IsMatch(expected));
    }

    @Test
    public void mirroredL() {
        Layout input = Layout.createLayout("0,0;1,0;2,0;2,1");
        Layout result = input.mirror();
        Layout expected = Layout.createLayout("0,0;1,0;2,0;0,1");
        assertTrue(result.IsMatch(expected));
    }

    @Test
    public void mirroredCross() {
        Layout input = Layout.createLayout("1,0;0,1;1,1;2,1;1,2");
        Layout result = input.mirror();
        assertTrue(result.IsMatch(input));
    }

    @Test
    public void mirroredStairs() {
        Layout input = Layout.createLayout("2,0;2,1;1,2;1,1;0,2");
        Layout result = input.mirror();
        Layout expected = Layout.createLayout("0,0;0,1;1,1;1,2;2,2");
        assertTrue(result.IsMatch(expected));
    }

    @Test
    public void turnedOne() {
        Layout input = Layout.createLayout("1,1");
        Layout result = input.turn90degrees(1);
        Layout expected = Layout.createLayout("0,0");
        assertTrue(result.IsMatch(expected));
    }

}
