package Engine;

import Engine.Model.Layout;
import Engine.Model.PlayerTilesSelection;
import Engine.Model.TerrainType;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class PlayerTilesSelectionTest {

    PlayerTilesSelection selection;

    @Before
    public void init() {
        selection = new PlayerTilesSelection();
    }

    @Test
    public void canChangeTerrainType() throws Exception {
        selection.AddTile(1,1, TerrainType.Farm);
        selection.AddTile(1,1, TerrainType.Water);

        assertEquals(TerrainType.Water, selection.GetTerrainType(1,1));
    }

    @Test(expected = Exception.class)
    public void invalidTerrainTypeThrowsException() throws Exception {
        selection.AddTile(1, 1, TerrainType.Monster);
    }

    @Test
    public void getLayoutTest() throws Exception {
        selection.AddTile(5, 5, TerrainType.Farm);
        selection.AddTile(6, 5, TerrainType.Farm);
        selection.AddTile(7, 5, TerrainType.Farm);
        Layout layout = selection.GetLayout();
        Layout expectedLayout = Layout.createLayout("0,0;1,0;2,0");
        assertTrue(layout.IsMatch(expectedLayout));
    }

    @Test
    public void allAreSame() throws Exception {
        selection.AddTile(5,4, TerrainType.Farm);
        selection.AddTile(5, 5, TerrainType.Forest);
        assertFalse(this.selection.areAllTerrainsSame());
    }
}
