package Engine;

import Engine.Builder.ArrangementRuleFactory;
import Engine.Model.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class ArrangementRuleTest {

    @Test
    public void testSameLayoutNoRotation() throws Exception {
        ArrangementRule rule = ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0;1,0;2,0"), false);
        PlayerTilesSelection selection = new PlayerTilesSelection();
        selection.AddTile(5, 5, TerrainType.Farm);
        selection.AddTile(6, 5, TerrainType.Farm);
        selection.AddTile(7, 5, TerrainType.Farm);

        var validationResult = rule.Check(selection);
        assertEquals(ValidationResult.Ok, validationResult);
    }

    @Test
    public void testDifferentLayout() throws Exception {
        ArrangementRule rule = ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0;1,0;2,0"), false);
        PlayerTilesSelection selection = new PlayerTilesSelection();
        selection.AddTile(5, 5, TerrainType.Farm);
        selection.AddTile(6, 5, TerrainType.Farm);
        selection.AddTile(6, 6, TerrainType.Farm);

        var validationResult = rule.Check(selection);
        assertEquals(ValidationResult.InvalidArrangement, validationResult);
    }

    @Test
    public void testTurnedLayout() throws Exception {
        ArrangementRule rule = ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0;0,1;0,2;1,1"), false);
        PlayerTilesSelection selection = new PlayerTilesSelection();
        selection.AddTile(7, 3, TerrainType.Farm);
        selection.AddTile(8, 3, TerrainType.Farm);
        selection.AddTile(9, 3, TerrainType.Farm);
        selection.AddTile(8, 4, TerrainType.Farm);

        var validationResult = rule.Check(selection);
        assertEquals(ValidationResult.Ok,validationResult);
    }

    @Test
    public void mirroredTurnedLayout() throws Exception {
        ArrangementRule rule = ArrangementRuleFactory.buildBasedOn(Layout.createLayout("0,0;0,1;1,1;1,2"), false);
        PlayerTilesSelection selection = new PlayerTilesSelection();
        selection.AddTile(7, 3, TerrainType.Farm);
        selection.AddTile(8, 3, TerrainType.Farm);
        selection.AddTile(9, 4, TerrainType.Farm);
        selection.AddTile(8, 4, TerrainType.Farm);

        var validationResult = rule.Check(selection);
        assertEquals(ValidationResult.Ok,validationResult);
    }
}
