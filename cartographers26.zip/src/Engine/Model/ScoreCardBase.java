package Engine.Model;

public class ScoreCardBase {
    public ScoreCardBase() {}
    public int score(PlayerSheet sheet) {
        return 0;
    }
}
