package Engine.Model;

/**
 * A felfedezőkártya típusai enum osztály.
 */
public enum DiscoveryCardType {
    Normal,
    Ruin,
    Ambush
}
